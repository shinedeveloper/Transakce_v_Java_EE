package net.sevecek.tablemodel;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
import javax.swing.table.*;

@SuppressWarnings("unchecked")
public class BeanTableModel<T> extends AbstractTableModel implements TableModel {

    private static final String[] DEFAULT_COLUMN_NAMES = {"1", "2", "3"};
    private static final String[] EMPTY_STRING_ARRAY = new String[0];

    private String beanClassName = "";

    private String[] propertyNames = EMPTY_STRING_ARRAY;
    private String[] defaultPropertyNames = EMPTY_STRING_ARRAY;

    private String[] columnNames = EMPTY_STRING_ARRAY;

    private List<T> rows = new LinkedList<T>();

    private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);


    public String getBeanClassName() {
        return beanClassName;
    }


    public void setBeanClassName(String clazzName) {
        if (clazzName == null) {
            throw new NullPointerException("beanClassName property must not be null");
        }
        String oldValue = beanClassName;
        beanClassName = clazzName;
        propertyChangeSupport.firePropertyChange("beanClassName", oldValue, beanClassName);

        if (isPropertyNamesDefaultValue()) {
            setDefaultPropertyNames();
        }
    }


    private boolean isPropertyNamesDefaultValue() {
        return propertyNames.length == 0 || Arrays.equals(defaultPropertyNames, propertyNames);
    }


    private void setDefaultPropertyNames() {
        Class clazz;
        try {
            clazz = Class.forName(beanClassName);
        } catch (ClassNotFoundException e) {
            return;
        }
        propertyNames = resolvePropertyNames(clazz);
        if (defaultPropertyNames.length == 0) {
            defaultPropertyNames = propertyNames;
        }
        fireTableStructureChanged();
    }


    public String[] getPropertyNames() {
        return propertyNames;
    }


    public void setPropertyNames(String[] newPropertyNames) {
        if (newPropertyNames == null) {
            newPropertyNames = EMPTY_STRING_ARRAY;
        }
        propertyNames = newPropertyNames;
        if (isPropertyNamesDefaultValue()) {
            setDefaultPropertyNames();
        } else {
            fireTableStructureChanged();
        }
    }


    private void ensurePropertyNamesMatchBeanProperties(String[] newPropertyNames) {
        Class clazz;
        try {
            clazz = Class.forName(beanClassName);
        } catch (ClassNotFoundException e) {
            return;
        }
        String[] beanPropertyNames = resolvePropertyNames(clazz);
        for (String newPropertyName : newPropertyNames) {
            boolean found = false;
            for (String beanPropertyName : beanPropertyNames) {
                if (newPropertyName.equals(beanPropertyName)) {
                    found = true;
                }
            }

            if (!found) {
                throw new IllegalArgumentException("Column name '" + newPropertyName + "' was not found amongst bean properties of class " + beanClassName);
            }
        }
    }


    @SuppressWarnings("unchecked")
    public void setRows(List<T> beans) {
        if (beans == null) {
            beans = new LinkedList<T>();
        }

        if (isBeanClassNameDefaultValue() && !beans.isEmpty()) {
            resolveClassNameFromList(beans);
        }
        rows = beans;
        fireTableDataChanged();
    }


    private boolean isBeanClassNameDefaultValue() {
        return beanClassName == null || beanClassName.isEmpty();
    }


    private void resolveClassNameFromList(List<T> beans) {
        Iterator<T> iterator = beans.iterator();
        T firstBean = iterator.next();
        Class<?> foundClass = firstBean.getClass();
        while (iterator.hasNext()) {
            T otherBean = iterator.next();
            if (!otherBean.getClass().isAssignableFrom(foundClass)) {
                foundClass = leastCommonSuperClass(otherBean.getClass(), foundClass);
            }
        }
        setBeanClassName(foundClass.getName());
    }


    private Class<?> leastCommonSuperClass(Class<?> firstClass, Class<?> secondClass) {
        Class[] firstClassInheritanceChain = resolveInheritanceChain(firstClass);
        Class[] secondClassInheritanceChain = resolveInheritanceChain(secondClass);
        Class lastMatching = Object.class;
        for (int i=0; i<Math.min(firstClassInheritanceChain.length, secondClassInheritanceChain.length); i++) {
            if (!firstClassInheritanceChain[i].equals(secondClassInheritanceChain[i])) {
                break;
            }
            lastMatching = firstClassInheritanceChain[i];
        }
        return lastMatching;
    }


    private Class[] resolveInheritanceChain(Class<?> aClass) {
        LinkedList<Class> inheritanceChain = new LinkedList<Class>();
        while (!aClass.equals(Object.class)) {
            inheritanceChain.addFirst(aClass);
            aClass = aClass.getSuperclass();
        }
        inheritanceChain.addFirst(Object.class);
        return inheritanceChain.toArray(new Class[inheritanceChain.size()]);
    }


    public void addPropertyChangeListener(PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(listener);
    }


    public void removePropertyChangeListener(PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(listener);
    }


    public void addPropertyChangeListener(String propertyName, PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(propertyName, listener);
    }


    public void removePropertyChangeListener(String propertyName, PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(propertyName, listener);
    }


    public String[] getColumnNames() {
        return columnNames;
    }


    public void setColumnNames(String[] names) {
        columnNames = names;
        fireTableStructureChanged();
    }


    public T getBeanAt(int rowIndex) {
        validateRowIndex(rowIndex);
        return rows.get(rowIndex);
    }


    private void validateRowIndex(int rowIndex) {
        if (rowIndex < 0) {
            throw new IndexOutOfBoundsException("Negative row numbers are not allowed");
        }
        if (rowIndex >= rows.size()) {
            throw new IndexOutOfBoundsException("Row number " + rowIndex + " was requested but table has only " + rows.size() + " rows");
        }
    }


    public int findBean(T bean) {
        Iterator<?> iterator = rows.iterator();
        for (int i = 0; iterator.hasNext(); i++) {
            if (bean.equals(iterator.next())) {
                return i;
            }
        }
        return -1;
    }


    public void addBean(T bean) {
        rows.add(bean);
        int row = rows.size() - 1;
        fireTableRowsInserted(row, row);
    }


    public T removeBean(T bean) {
        int rowIndex = findBean(bean);
        return removeBean(rowIndex);
    }


    public T removeBean(int rowIndex) {
        T originalBean = rows.remove(rowIndex);
        fireTableRowsDeleted(rowIndex, rowIndex);
        return originalBean;
    }


    public void updateBean(T bean) {
        int rowIndex = findBean(bean);
        updateBean(rowIndex, bean);
    }


    public void updateBean(int rowIndex, T bean) {
        T originalBean = rows.get(rowIndex);
        if (originalBean != bean) {
            rows.set(rowIndex, bean);
        }
        fireTableRowsUpdated(rowIndex, rowIndex);
    }

    //----------------------------------------------------------------

    public int getRowCount() {
        return rows.size();
    }


    public int getColumnCount() {
        if (propertyNames.length == 0) {
            return DEFAULT_COLUMN_NAMES.length;
        }
        return propertyNames.length;
    }


    @Override
    public String getColumnName(int columnIndex) {
        validateColumnIndex(columnIndex);
        if (columnNames.length <= columnIndex) {
            return propertyNames[columnIndex];
        }
        return columnNames[columnIndex];
    }


    public Object getValueAt(int rowIndex, int columnIndex) {
        T bean = getBeanAt(rowIndex);
        validateColumnIndex(columnIndex);
        String propertyName = propertyNames[columnIndex];
        Object value = getPropertyValue(bean, propertyName);
        return value;
    }

    //-------------------------------------------------------------------------

    private void validateColumnIndex(int columnIndex) {
        if (columnIndex < 0) {
            throw new IndexOutOfBoundsException("Negative column numbers are not allowed");
        }
        if (columnIndex > propertyNames.length) {
            throw new IndexOutOfBoundsException("Column number " + columnIndex + " was requested but table has only " + propertyNames.length + " columns");
        }
    }


    private Object getPropertyValue(T bean, String propertyName) {
        try {
            try {
                Method getter = bean.getClass().getMethod(resolveGetter(propertyName));
                return getter.invoke(bean);
            } catch (NoSuchMethodException e) {
                throw new RuntimeException(e);
            } catch (InvocationTargetException e) {
                throw new RuntimeException(e);
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        } catch (RuntimeException rex) {
            return "<invalid-column>";
        }
    }


    private String resolveGetter(String propertyName) {
        StringBuilder getterName = new StringBuilder(propertyName.length() + 3);
        getterName.append("get");
        getterName.append(Character.toUpperCase(propertyName.charAt(0)));
        getterName.append(propertyName.substring(1));
        return getterName.toString();
    }


    private String[] resolvePropertyNames(Class<T> clazz) {
        Method[] methods = clazz.getMethods();
        List<String> propertyNames = new ArrayList<String>(methods.length);
        for (Method singleMethod : methods) {
            String methodName = singleMethod.getName();
            if (methodName.startsWith("get") && singleMethod.getParameterTypes().length == 0 && !methodName.equals("getClass")) {
                char firstChar = methodName.charAt(3);
                if (methodName.length() > 4) {
                    String propertyName = Character.toLowerCase(firstChar) + methodName.substring(4);
                    propertyNames.add(propertyName);
                } else {
                    String propertyName = Character.toString(Character.toLowerCase(firstChar));
                    propertyNames.add(propertyName);
                }
            }
        }
        return propertyNames.toArray(new String[propertyNames.size()]);
    }


    private String[] transformPropertyNamesToColumnNames() {
        String[] columns = new String[propertyNames.length];
        for (int i = 0; i < propertyNames.length; i++) {
            String propertyName = propertyNames[i];
            columns[i] = transformPropertyNameToColumnName(propertyName);
        }
        return columns;
    }


    private String transformPropertyNameToColumnName(String propertyName) {
        StringBuilder name = new StringBuilder(propertyName.length() * 2);
        for (int i = 0; i < propertyName.length(); i++) {
            int letter = propertyName.codePointAt(i);
            if (i == 0) {
                name.appendCodePoint(Character.toUpperCase(letter));
            } else if (Character.isUpperCase(letter)) {
                name.append(' ');
                name.appendCodePoint(Character.toLowerCase(letter));
            } else {
                name.appendCodePoint(letter);
            }

            if (Character.isSupplementaryCodePoint(letter)) {
                i++;
            }
        }
        return name.toString();
    }
}
